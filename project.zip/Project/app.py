#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st
from keras.models import load_model


# In[ ]:


import streamlit as st


def predictions(features):
    model=load_model('final_model.h5')
    prediction=model.predict(features)
    print(prediction)
    return prediction

def main():
    st.title('SONAR ROCK DETECTION')
    html_temp='''
    <div style="background-color:blue;padding:13px">
    <h1 style="color:black;text-align:center;">Streamlit Sonar Detection
    </div>
    '''
    
    st.markdown(html_temp, unsafe_allow_html=True)
    
    a1=st.text_input('Attr1: ', '0.5')
    
    result=""
    
    if st.button('Predict'):
        result=predictions([a1,])
    st.success(f'The result is: {result}')
    

if __name__=='__main__':
    main()

