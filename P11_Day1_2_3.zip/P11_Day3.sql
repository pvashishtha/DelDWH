-- JOINS (cont...)

-- Non-Equi Joins
-- select * from T1 JOIN T2 ON T1.col1 = T2.col2;
-- <, >, <=, >=, IN, BETWEEEN, LIKE

create table salgrade(grade char(1), minsal int, maxsal int);
insert into salgrade values('A', 20000, 30000);
insert into salgrade values('B', 15000, 19999);
insert into salgrade values('C', 10000, 14999);
insert into salgrade values('D', 5000, 9999);
insert into salgrade values('E', 2000, 4999);

-- JOIN employee with salgrade to obtain grade values
select e.employee_id, e.first_name, e.last_name, e.salary, g.grade
    from employee e JOIN salgrade g
    ON e.salary between g.minsal and g.maxsal;

-- Create a table job_roles that contains labelling for job_id. Join this with employee on basis of pattern 
--  of job_id values using like operator.
create table job_roles(pattern varchar2(10), job_role varchar2(20));
insert into job_roles values('%_MAN', 'Manager');
insert into job_roles values('%_PRES', 'President');
insert into job_roles values('%_VP', 'Vice President');
insert into job_roles values('%_CLERK', 'Clerical');
insert into job_roles values('%_REP', 'Sales Representative');

select e.employee_id, e.first_name, e.job_id, j.job_role from employee e JOIN job_roles j
    ON e.job_id like j.pattern;

-- SELF JOIN
    -- where table is joined to itself
    -- both left and right table are same

-- Find the details of employees with their manager name

select e.employee_id, e.first_name, e.last_name, e.salary, e.manager_id, 
    m.first_name as m_fname, m.last_name as m_lname, m.salary as m_salary, m.job_id as m_jobid
    from employee e JOIN employee m
    ON e.manager_id=m.employee_id;

-- Advanced DML operations
    -- MERGE

create table empdata(eid int, fname varchar2(20), lname varchar2(20), salary number);

insert into empdata values(100, 'Steven', 'King', 27000);
insert into empdata values(300, 'Prateek', 'Vashishtha', 23000);

alter table employee disable constraint SYS_C005273222;

select * from user_constraints where table_name='EMPLOYEE';

desc employee;

MERGE INTO employee e1
USING empdata e2
ON (e1.employee_id=e2.eid)
WHEN MATCHED THEN 
    UPDATE SET e1.salary=e2.salary
WHEN NOT MATCHED THEN
    INSERT(employee_id, first_name, last_name, salary)
    VALUES(e2.eid, e2.fname, e2.lname, e2.salary);


select * from employee;

-- Error Log with Merge
create table empcopy as select * from employee;
delete from empcopy where EMPLOYEE_ID=300;

EXECUTE DBMS_ERRLOG.CREATE_ERROR_LOG('empcopy', 'TAB_ERR_LOG_EMPCOPY');

MERGE INTO empcopy e1
USING empdata e2
ON (e1.employee_id=e2.eid)
WHEN MATCHED THEN 
    UPDATE SET e1.salary=e2.salary
WHEN NOT MATCHED THEN
    INSERT(employee_id, first_name, last_name, salary)
    VALUES(e2.eid, e2.fname, e2.lname, e2.salary)
    LOG ERRORS INTO TAB_ERR_LOG_EMPCOPY('TAG_STATEMENT') REJECT LIMIT 1000;

-- entire merge operation will be rollback if error exceeed 1000 limit.

alter table empcopy modify hire_date not null;

select * from TAB_ERR_LOG_EMPCOPY;

select * from empcopy;

-- View 
    -- Virtual Table
    -- Has similar structure to tables
    -- View does not occupy storage for data
    -- View can render data related to one or more tables

-- create view <name> as <select query>

create view emp_name_id as select employee_id, first_name from employee;

select * from emp_name_id;

drop view emp_details;

create view emp_details as select employee_id, first_name, last_name, salary, department_id 
    from employee where department_id=30;

-- perform DML operations on view & table

update employee set salary=salary*3 where department_id=30;

select * from employee where department_id=30;

select * from emp_details;

-- changes done through view
update emp_details set salary=7700 where first_name='Den';

select * from employee where department_id=30;

select * from emp_details;

-- READ ONLY VIEW
create view emp_details_2 as select employee_id, first_name, last_name, salary, department_id 
    from employee where department_id=30 WITH READ ONLY;

select * from emp_details_2;

update emp_details_2 set salary=9900 where first_name='Den';


-- Simple View -> constructed using single table
-- Complex View -> constructed using multiple table, complex queries, like join, subquery, aggreagtions

create view emp_dept_details as select e.employee_id, e.first_name, e.last_name, e.salary, d.department_name
    from employee e JOIN department d on e.department_id=d.department_id;

select * from emp_dept_details;

create view emp_summary as select count(*) cnt, sum(salary) tot_sal, round(avg(salary)) avg_sal, 
    min(salary) minsal, max(salary) maxsal from employee;

update employee set salary=salary*1.20;

select * from emp_summary;

-- materialised views
    -- can record periodically updated information

create MATERIALIZED view emp_dash_2 as select sum(salary), round(avg(salary)) from EMPLOYEE;

select * from emp_dash_2;

select * from user_tables;

-- Temporary Tables
    -- are like regular table but can hold data temporarily only
    -- all data is truncated automatically when user session ends

-- Global Temporary Table
    -- are same as tempporary table, but can be shared with users
    -- data truncated as user session ends

create global temporary table emptemp_table as select * from employee where department_id=90;

insert into emptemp_table value select * from employee where department_id=90;
update emptemp_table set salary=salary/5;
select * from emptemp_table;

-- Analytical Functions
    -- ROW_NUMBER, RANK, DENSE_RANK, LAST_VALUE, FIRST_VALUE, LAG, LEAD, LISTAGG

-- Windowing => working over a set of data at a time.
-- OVER(partition by <col> order by <col>)

-- ROW_NUMBER

select employee_id, first_name, department_id, salary,
ROW_NUMBER() OVER(order by salary desc) as rn
from employee;

select employee_id, first_name, department_id, salary,
ROW_NUMBER() OVER(partition by department_id order by salary desc) as rn
from employee;

-- RANK()
select employee_id, first_name, department_id, salary,
ROW_NUMBER() OVER(order by salary desc) as rn,
RANK() OVER(order by salary desc) as rnk
from employee;

-- DENSE_RANK
select employee_id, first_name, department_id, salary,
ROW_NUMBER() OVER(order by salary desc) as rn,
RANK() OVER(order by salary desc) as rnk,
DENSE_RANK() OVER(order by salary desc) as drnk
from employee;


-- Find the top earners for each department using RANK and DENSE RANK

select employee_id, first_name, salary, department_id from (
    select employee_id, first_name, salary, department_id,
    rank() over(partition by department_id order by salary desc) as rnk
    from employee
) where rnk=1;

-- FIRST_VALUE(col)

select employee_id, first_name, department_id, salary,
first_value(salary) over(partition by department_id order by salary desc) as fv
from employee;

select employee_id, first_name, department_id, salary,
first_value(salary) over(partition by department_id order by salary desc) as fv,
last_value(salary) over(partition by department_id order by salary desc ROWS BETWEEN UNBOUNDED PRECEDING AND
 UNBOUNDED FOLLOWING) as lv
from employee;

-- Find the cumulative sum of salary values for entire company against each record
select employee_id, first_name, salary,
sum(salary) over(order by salary ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumulative_sum
from employee;

-- LAG(column, offset, default_value)
select employee_id, first_name, salary,
LAG(salary, 3, 0) over(order by salary) as lg
from employee;

-- LEAD(column, offset, default_value)
select employee_id, first_name, salary,
LAG(salary, 2, 0) over(order by salary) as lg,
LEAD(salary, 2, 0) over(order by salary) as ld
from employee;

-- LISTAGG(column, separator_symbol)
    -- aggregate character data into single cell from multiple records

select department_id, LISTAGG(first_name, ', ') WITHIN GROUP (ORDER BY first_name) as employees
from employee group by department_id;

select department_id, LISTAGG(distinct job_id, ', ') WITHIN GROUP (ORDER BY job_id) as job_roles
from employee group by department_id;


-- Synonyms
    -- Are simply another name for a schema object
    -- We can use synonym name for performming operations with object
    -- syntax: create synonym <name> for <object>;

drop table emp; 

create or replace synonym emp for employee;

select * from emp;

select * from employee;

update emp set salary=12000 where employee_id=300;

-- delete synonym
    drop synonym emp;

-- Sequence
    -- object to generate sequential numeric values
    -- sequence are independent, not belonging to any table/view
    -- start with -> telle system what should be starting value of seq
    -- incremrent by -> incements value by factor given
    -- minvalue | nominvalue
    -- maxvalue | nomaxvalue
    -- cycle | nocycle
    -- cache n | nocache

create sequence new_seq
    start with 10
    increment by 1
    minvalue 5
    maxvalue 15
    cycle 
    nocache;

select new_seq.NEXTVAL from dual;

create table sample9(sid int, sample_desc varchar2(20));

insert into sample9 values(new_seq.nextval, 'Sample_'||new_seq.currval);

select * from sample9 order by sid;

-- alter seq
    alter sequence new_seq increment by 3 maxvalue 100 cache 3;

drop sequence new_seq;


-- Hierarchical Retrieval

    -- CEO > Director > VP > Manager > Consultant  => Top down hierarchy
    -- Consultant > Manager > VP > Director > CEO => Bottom up hierarchy

select employee_id, first_name, last_name, manager_id from employee
    CONNECT BY PRIOR employee_id=manager_id;

select employee_id, first_name, last_name, manager_id from employee
    START WITH employee_id=100
    CONNECT BY PRIOR employee_id=manager_id;

select employee_id, first_name, last_name, manager_id from employee
    START WITH employee_id=100
    CONNECT BY PRIOR employee_id=manager_id
    ORDER SIBLINGS BY first_name;

select employee_id, first_name, last_name, manager_id, LEVEL from employee
    START WITH employee_id=100
    CONNECT BY PRIOR employee_id=manager_id
    ORDER SIBLINGS BY first_name;


-- Bootom up retrieval
    -- CONNECT BY ROOT

select first_name "Employee", CONNECT_BY_ROOT first_name "Manager",
LEVEL-1 "Pathlen", SYS_CONNECT_BY_PATH(first_name, '/') "Path"
from employee where LEVEL>1 and department_id=20
CONNECT BY PRIOR employee_id=manager_id
ORDER BY "Employee", "Pathlen", "Manager", "Path";


--
drop table customer CASCADE CONSTRAINTS;
drop table flight CASCADE CONSTRAINTS;
drop table booking CASCADE CONSTRAINTS;

create table customer(
custid varchar2(5) primary key check(custid like 'C%'),
custname varchar2(10));

create table flight(
flightid varchar2(5) primary key check (flightid like 'F%'),
flightname varchar2(15),
flighttype varchar2(20) check (flighttype in ('Domestic','International')),
source varchar2(15),
destination varchar2(15)
);

Alter table flight modify flightname varchar2(20);

create table booking(
bookingid number primary key,
flightid varchar2(5) references flight(flightid),
custid varchar2(5) references customer(custid),
travelclass varchar2(30) check(travelclass in('Business','Economy')),
flightcharge number,
bookingdate date
);

insert into customer values('C301','John');
insert into customer values('C302','Sam');
insert into customer values('C303','Robert');
insert into customer values('C304','Albert');
insert into customer values('C305','Jack');

insert into flight values('F101','Spice Jet Airlines','Domestic','Mumbai','Kolkata');
insert into flight values('F102','Indian Airlines','International','Delhi','Germany');
insert into flight values('F103','Deccan Airlines','Domestic','Chennai','Bengaluru');
insert into flight values('F104','British Airways','International','London','Italy');
insert into flight values('F105','Swiss Airlines','International','Zurich','Spain');


insert into booking values(201,'F101','C301','Business',12000,'22-Mar-18');
insert into booking values(202,'F105','C303','Business',30000,'17-May-18');
insert into booking values(203,'F103','C302','Economy',3000,'23-Jun-18');
insert into booking values(204,'F101','C302','Economy',10000,'12-Oct-18');
insert into booking values(205,'F104','C303','Business',25000,'16-Jan-19');
insert into booking values(206,'F105','C301','Business',30000,'22-Jan-19');
insert into booking values(207,'F104','C304','Economy',22000,'16-Feb-19');
insert into booking values(208,'F101','C304','Business',12000,'18-Sep-19');


select * from customer;
select * from flight;
select * from booking;

--------------------------
--