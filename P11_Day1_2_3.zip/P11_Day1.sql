select * from co.customers;

-- Write query to find the count of customers
select count(customer_id) from co.customers;

-- Write query to print unique product names
select * from co.products;

select distinct product_name from co.products;

-- write query to find the orders that are completed
select * from co.orders;
desc co.orders;

select count(*) from co.orders where order_status='COMPLETE';

-- write query to print distinct store names

select * from co.stores;

select distinct store_name from co.stores;

-- Find all employees who belong to either department 30 or has salary more than 12000
select employee_id, first_name, salary, department_id from hr.employees where department_id=30 or salary>12000;

-- Find all employees who work as 'SA_REP' job role
select employee_id, first_name, salary, department_id from hr.employees where job_id='SA_REP';

-- Find all employees who has 'MAN' in their job id
select employee_id, first_name, salary, job_id from hr.employees where job_id like '%MAN%';

-- like => % (matches any number of chars)  _ (matches single character)  


select employee_id, first_name, salary, job_id from hr.employees where job_id like '%#_MAN' ESCAPE '#';


-- Find all empoyees whose name starts with 'a' or 'A' and ends with 'n' or 'N'

select employee_id, first_name from hr.employees 
    where upper(first_name) like 'A%N';

-- Write query to find all employees in department 80 printed in ascending order of salary

select employee_id, first_name, salary, job_id from hr.employees
    where department_id=80
    order by salary desc;

select employee_id, first_name, salary, job_id from hr.employees
    where department_id=80
    order by 2;

-- Write query to display employees who earn less than 5000 sorted by department and then by name

select employee_id, department_id, first_name, salary from hr.employees
    where salary<5000
    order by department_id, first_name;

select employee_id, department_id, first_name, salary from hr.employees
    where salary<5000
    order by 2, 3;

-- Write query to find job_id where department is either 50, 80, 30, 60, 110

select distinct job_id from hr.employees where department_id IN(30,50,80,60,110);

-- Write query to find department names who has no manager

select department_name from hr.departments where manager_id is null;

-- Write a query to get first 3 employees of department 80 when sorted by first name

select employee_id, first_name, salary from hr.employees
    where department_id=80
    order by first_name
    fetch first 3 rows only;

select employee_id, first_name, salary from hr.employees
    where department_id=80 and rownum<4
    order by first_name;

-- fetch next 5 rows
select employee_id, first_name, salary from hr.employees
    where department_id=80
    order by first_name
    offset 3 rows
    fetch first 5 rows only;

-- DDL

-- Create a table student with columns like id, fullname, course date_of_enroll, fees
create table student(sidid int, fullname varchar2(50), course varchar2(30), date_of_enroll date,
    fees number(8,2));

-- add a column to existing table called active_status
alter table student add active_status varchar2(10);

-- change column width for fullname to 100
alter table student modify fullname varchar2(100);


-- change the datatype of column active_status to integer instead of char orginally
alter table student modify active_status INTEGER;

-- remove column active_status
alter table student drop column active_status;

-- rename column fees to course_fee
alter table student rename column fees to course_fee;

desc student;

-- Enter 5 records in table and then perform adding of column, altering datatype and removing column

insert into student values(10, 'Prateek', 'SQL', '22-Jan-26', 23000);
insert into student values(20, 'Aditi', 'PLSQL', '22-Feb-26', 25000);
insert into student values(30, 'Saksham', 'Java', '19-Jan-26', 13000);
insert into student values(40, 'Simant', 'Python', '09-Feb-26', 19000);
insert into student values(50, 'Sanjay', 'Java', '15-Feb-26', 21000);

select * from student;

alter table student add status char(1);

alter table student modify fullname varchar2(5);

alter table student modify course_fee integer;

alter table student modify date_of_enroll varchar2(100);

alter table student drop column course_fee;

select * from student;

-- create a copy of employee and department table
create table employee as select * from hr.employees;

create table department as select * from hr.departments;

select * from employee where department_id=20;

-- update salary of employees who work in department 80 by factor of 1.2
update employee set salary=salary*1.2 where department_id=80;

-- update email of employees in department 30 changing it to lower case and adding '@email.com'
update employee set email=lower(email)||'@email.com' where department_id=30;

-- update phone number for department 20, change dot to hyphen
update employee set phone_number=replace(phone_number,'.','-') where department_id=20;

-- Rollback and Commit

select first_name, salary, job_id from employee where department_id=10;

update employee set salary=salary*3 where department_id=10;
rollback;

delete from employee where department_id=10;
rollback;

--
update employee set salary=salary/3 where department_id=10;
commit;
update employee set first_name=upper(first_name) where department_id=10;
rollback;
select first_name, salary, job_id from employee where department_id=10;
 
-- grant and revoke
-- GRANT <priviliges-list> ON <object> TO <user> [WITH "GRANT | ADMIN | HIERARCHY" OPTION]; 

grant select, update on employeee to user20 with grant option;
-- grant to others same priviliges

grant select, update on employeee to user20 with admin option;
-- grant system priviliges to others

grant select, update on employeee to user20 with hierarchy option;
-- grant view and subview on object to others

-- revoke
-- revoke <priviliges-list> ON <object> FROM <user>;


revoke update on employee from user;

-- revoke <system-priviliges> FROM user;
-- revoke <role> FROM user;
-- revoke all priviliges from user;

-- create user command

-- create user <username>@<server> identified by <password>;

create user 'ayush'@'localhost' identified by 'ayush12345';

create user 'ayush'@'%' identified by 'ayush@123';

grant all priviliges on *.* to ayush with grant option;

grant select, update on hr.employees to ayush123 with grant option;


-- 

-- write query to fetch email id for employees of department 30 and print them in lowercase with domain '@email.com'

-- write query to print name and salary of employees along with updated salary that is 12% higher than existing salary
select first_name, salary, salary*1.12 as new_salary from employee;

-- Find all employees who are not assigned any manager

-- Find count of employees who earn commission also

-- Find job_id of employees who earn commission

--
-- Truncate vs Delete

delete from stduent;
-- it can be rollback
-- its DML
-- memory space is not cleared/free
-- any active delete trigger will fire for each row

truncate table student;
-- DDL op
-- can not be rollback
-- free up memory storage
-- trigger is not fired

-- Constraints
-- PK, UNIQUE, NOT NULL, DEFAULT, CHECK, FK

-- PK => unique, not null
-- formed using 1 or more columns
-- there is always either zero or 1 PK for a table

-- constraints can be defined at column level and some at table level too
-- COLUMN LEVEL => PK, UNIQUE, NOT NULL, DEFAULT, CHECK, FK
-- ONLY AT COLUMN LEVEL => DEFAULT and NOT NULL
-- TABLE LEVEL => CHECK, PK, FK, UNIQUE

create table sample_product(
    sid int primary key,
    sample_desc varchar2(20) NOT NULL,
    sample_price number DEFAULT 0,
    sample_type varchar2(20) CHECK(sample_type IN ('CONSUMER', 'DOMESTIC', 'INTERNATIONAL')),
    sample_code int UNIQUE
    );

insert into sample_product(sid, sample_price, sample_type, sample_code) values(903, 290, 'DOMESTIC', 4003);

insert into sample_product(sid, sample_desc, sample_type, sample_code) values(904, 'sample904', 'DOMESTIC', 4004);

select * from sample_product;

create table new_sample_product(
    sid int,
    sample_desc varchar2(20) NOT NULL,
    sample_price number DEFAULT 0,
    sample_type varchar2(20),
    sample_code int,
    CONSTRAINT sid_pk primary key (sid),
    CONSTRAINT scode_uq unique(sample_code),
    CONSTRAINT stype_check CHECK(sample_type IN ('CONSUMER', 'DOMESTIC', 'INTERNATIONAL'))
    );

insert into new_sample_product values(904, 'sample904', 240, 'RETAIL', 404);

-- enable or disable constaints
alter table new_sample_product disable constraint stype_check;

alter table new_sample_product disable primary key cascade;

alter table new_sample_product enable novalidate constraint stype_check;

update new_sample_product set sample_type='CONSUMER' where sample_type='RETAIL';

select * from new_sample_product;

alter table new_sample_product drop constraint stype_check;

alter table new_sample_product add constraint stype_check check(sample_type IN ('DOMESTIC','RETAIL','CONSUMER','INTERNATIONAL'));

-- Foreign Key

drop table table products;

drop table sales;

create table products(pid int primary key, pname varchar2(20), price number);
insert into products values(401, 'keyboard', 300);
insert into products values(402, 'mouse', 150);
insert into products values(403, 'camera', 750);
insert into products values(404, 'mic', 400);
insert into products values(405, 'headset', 1200);

create table sales(sid int primary key, sdate date not null, prodid int,
    constraint pid_fk foreign key(prodid) references products(pid) ON DELETE CASCADE);

insert into sales values(10, '10-Jan-26', 401);
insert into sales values(20, '13-Jan-26', 402);
insert into sales values(30, '17-Jan-26', 402);
insert into sales values(40, '18-Jan-26', 403);
insert into sales values(50, '06-Feb-26', 405);
insert into sales values(60, '18-Feb-26', 405);
insert into sales values(70, '20-Feb-26', 401);

delete from products where pid=405;

insert into sales values(80, '21-Feb-26', 408);

select * from products;

select * from sales;

--

-- Write queries to add primary key to employee and department table
alter table department add constraint deptid_pk primary key (department_id);

alter table employee add constraint eid_pk primary key (employee_id);

-- Write query to add foreign key to employee table
alter table employee add constraint did_fk foreign key(department_id) references department(department_id);

-- write query to add unique constraint to department name
alter table department add constraint dept_uq unique(department_name);

-- write query to add check that job_id always has (_) underscore symbol in between
alter table employee add constraint job_check check(job_id like '%\_%' escape '\');

-- Index
-- clustered
-- non clustered

-- create index
    -- create index <name> on tablename(columns);

create index job_idx on employee(job_id); 

-- avoid DML usage
alter index job_idx unusable;

alter index job_idx rebuild;

-- avoid optimization
alter index job_idx invisible;

alter index job_idx visible;

-- complete disablement or usage stop
alter index job_idx disable;

alter index job_idx enable;

-- drop index

drop index job_idx;

-- 

-- Single Row Functions
    -- character functions
    -- numeric functions
    -- general functions
    -- date functions
    -- conversion functions

-- character functions => upper, lower, initcap, concat, replace, substr, instr, lpad, rpad, trim, rtrim, ltrim
        -- length, 

select first_name, upper(first_name), lower(first_name) from employee;

select initcap('hello world') from dual;

select initcap('HELLO world') from dual;

select length('hello world') from dual;

-- concat
select concat(first_name, last_name) from employee;

-- new version
select concat(first_name, ' ', last_name) from employee;

-- old version
select concat(concat(first_name, ' '), last_name) from employee;

select first_name || ' ' || last_name from employee;

-- replace 

select first_name, replace(first_name, 'a', '@') as newname from employee;

select first_name, replace(lower(first_name), 'a', '@') as newname from employee;

-- substr
select first_name, substr(first_name, 1, 3) from employee;

select first_name, last_name, substr(first_name, 1, 1) || substr(last_name, 1,1) initials from employee;

-- INSTR -> find / search occurence of substring, returns index location if found, else 0
-- INSTR(str, match, start, nth_occurence[1])

select INSTR('hello', 'l', -1) from dual;

select INSTR('hello', 'l', 1,2) from dual;

select INSTR('abrakadabra', 'a', 1,3) from dual;

select INSTR('abrakadabra', 'a', 3,3) from dual;

select INSTR('abrakadabra', 'a', 3,10) from dual;

-- lpad, rpad -> add padding chracters to either left or right of string making string of fixed size

select lpad('hello', 10, '*') from dual;

select rpad('hello', 20, '#') from dual;

select first_name, salary, lpad(salary, 6, '*') from employee;

-- trim, ltrim, rtrim

-- trim -> remove white spaces from either ends

select trim('    hello    ') from dual;
select length(trim('    hello    ')) from dual;


select ltrim('    hello    ') from dual;
select length(ltrim('    hello    ')) from dual;

select rtrim('    hello    ') from dual;
select length(rtrim('    hello    ')) from dual;

create table trial2(mydata varchar2(20));

insert into trial2 values(trim('    hello    '));
insert into trial2 values(ltrim('    hello    '));
insert into trial2 values(rtrim('    hello    '));

select * from trial2;

-- ltrim(str, 'match_chars') and rtrim(str, 'match_chars')

select ltrim('@#$@#$@#$@@@##$HELLO@#$%#$$@', '@#$') from dual;

select rtrim('@#$@#$@#$@@@##$HELLO@#$%#$$@', '@#$%') from dual;

select ltrim('Server IP: 201.198.45.67', 'Server IP: ') from dual;

--

-- Write a query to count number of occurence of blank spaces in a given string - "honesty is best policy today!"

select length('honesty is best policy today!') - length(replace('honesty is best policy today!', ' ', '')) 
    from dual;

-- Write query to count number of occurence of character 'a' in first names of employee irrespective of case

select first_name, length(first_name)-length(replace(lower(first_name), 'a', '')) a_cnt from employee
    order by a_cnt desc;


-- Numeric Functions
-- abs, ceil, floor, round, power, sin, cos, tan, log, sqrt

select abs(-245) from dual;

select ceil(7.78), floor(7.78), round(7.43), round(7.78, 1) from dual;

select power(2, 8) from dual;

select sqrt(81) from dual;

select sin(40), cos(90), tan(90) from dual;

select log(4,2) from dual;

select mod(56, 3) from dual;

select round(3.986545284, 2), trunc(3.986545284, 2) from dual;


-- write query to display name, salary and commission as percentage value rounded off to 1 decimal place.

select first_name, salary, round((commission_pct*100),1) newcomm from employee
    order by newcomm desc;


-- Write query to display the first_name with maximum length in employee table

select first_name, length(first_name) len from employee order by len desc fetch first 1 rows only;

-- Write query to find first_name that has maximum number of 'e' in its name irrespective of case

select first_name, length(first_name)-length(replace(lower(first_name), 'e', '')) a_cnt from employee
    order by a_cnt desc fetch first 1 rows only;