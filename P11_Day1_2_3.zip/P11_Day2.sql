-- General Functions
    -- NVL, NVL2, COALEASCE, NULLIF, DECODE, CASE, REGEXP_LIKE, REGEXP_REPLACE

-- NVL(value/col, null_decoding_value) -> data type of both args should be same

select commission_pct, NVL(commission_pct, 0) updated_comm from employee;

-- NVL2(value/col, not_null_value, null_value) -> both null_value and not_null_value args should be same datatype

select commission_pct, NVL2(commission_pct, 1, 0) updated_comm from employee;

-- DECODE(value/col, match, match_decode, unmatch_decode) -> both match_decode, unmatch_decode must be same datatype

select hire_date, decode(to_char(hire_date, 'YYYY'), '2012', 1, 0) from employee;

select first_name, decode(substr(first_name,1,1), 'A', 'FOUND', 'NOT FOUND') name_a from employee;

-- COALESCE(list_values) -> returns first non null value

select first_name, commission_pct, salary, COALESCE(commission_pct, salary) find_non_null from employee;

select COALESCE(null, null, null, null, null, null, null, null, null) from dual;

-- CASE

/*  [equiality relation of expr with x|y|z]
CASE <expr> 
    WHEN x THEN a1 
    WHEN y THEN a2 
    WHEN z THEN a3 
    ELSE a4 
    END as <alias-name> 
*/

/*  [non-equiality relation of expr with x|y|z]
CASE 
    WHEN expr_of_x THEN a1 
    WHEN expr_of_y THEN a2 
    WHEN expr_of_z THEN a3 
    ELSE a4 
    END as <alias-name> 
*/

select job_id, 
case job_id
    when 'AD_PRES' then 'PRESIDENT'
    when 'AD_VP' then 'VICE PRESIDENT'
    when 'IT_PROG' then 'PROGRAMMER'
    when 'SA_REP' then 'SALES REPRESENTATIVE'
    else 'OTHERS'
end as job_roles
from employee;

-- For employee table check salary values, if they are less than 8000 then display low salary else display high salary

select first_name, salary,
CASE 
    WHEN salary<8000 THEN 'LOW SALARY'
    ELSE 'HIGH SALARY'
END AS salary_check
from employee;

-- For employee table, display all employee name, and their salary. Also, generate updated_salary column
    -- that displays new salary values after increment by factor of X as per given table of salary ranges:
    -- For salary between 2000 and 5000, X=1.2
    -- For salary between 5000 and 10000, X=1.1
    -- For salary in range 10000 and 15000, X-1.05
    -- For salary more than 15000, X=1

select first_name, salary,
case 
    when salary between 2000 and 4999 then salary*1.2
    when salary between 5000 and 9999 then salary*1.1
    when salary between 10000 and 14999 then salary*1.05
    when salary>=15000 then salary
    else 0
end as new_salary
from employee;

-- REGEXP_LIKE, REGEXP_REPLACE

select first_name, last_name from employee where REGEXP_LIKE(first_name, '^Ste(v|ph)en$');

select first_name, phone_number from employee where REGEXP_LIKE(phone_number, '^[0-9]{2}\.[0-9]*');


select phone_number, REGEXP_REPLACE(phone_number, '\.', '-') from employee;

select country_name, REGEXP_REPLACE(country_name, 'land$', 'world') from hr.countries;

-- Find all employees who has job role of manager. That is, where job_id ends with '_MAN'.

select first_name, job_id from employee where REGEXP_LIKE(job_id, '^[A-Z]+_MAN$');

-- Conversion Functions
-- number to char -> to_char()
-- date to char -> to_char()
-- char to date -> to_date()
-- char to number -> to_number()

-- to_number()

select to_number('234') from dual;

select to_number('234')+10 from dual;

select '234' + 10 from dual;

select to_number('234.78') from dual;

select to_number('234%') from dual;

-- to_date()

select to_date('25-Dec-25') from dual;

insert into student values(90, 'Prateek', 'SQL', to_date('20-Feb-26'), 'Y');

insert into student values(90, 'Prateek', 'SQL', to_date('20/02/2026', 'DD/MM/YYYY'), 'Y');

select * from student;


select to_date('FRIDAY20202602105901AM', 'DAYDDYYYYMMHHMISSAM') from dual;


-- to_char()

select to_char(3.14567) from dual;

select to_char(to_date('20-Feb-26'), 'YYYY MM DD') from dual;

select to_char(to_date('20-Feb-26'), 'Day DD Month, YYYY') from dual;

select hire_date, to_char(hire_date, 'Day DD Mon, YYYY') from employee;

-- Display employee names and salary in currency format like $3,500

select first_name, to_char(salary, '$999,999,999.99') from employee;

-- Date Functions
-- months_between(date, date)

select months_between(sysdate, '04-Nov-24') from dual;

select first_name, hire_date, round(months_between(sysdate, hire_date)) as exp from employee;

-- find the person with most experience in company
select first_name, round(months_between(sysdate, hire_date)/12) as exp from employee
    order by exp desc fetch first 1 rows only;


select first_name, round(sysdate-hire_date) as days from employee order by days desc fetch first 1 rows only;

-- add_months(date, months)

select add_months(sysdate, 6) from dual;

select add_months(sysdate, 204) from dual;

-- Find the year in which employee will retire if retiring happens after 20 years of service.

select first_name, to_char(add_months(hire_date, 240), 'YYYY') as retiring_in from employee;

-- LAST_DAY(date) => returns last day of the month of given date

select last_day(sysdate) from dual;

-- find whether employees were hired in leap year or not
select first_name, 
case to_char(last_day(to_date('01-Feb-'||to_char(hire_date, 'YYYY'), 'DD-Mon-YYYY')),'DD')
when '29' then 'LEAP YEAR'
else 'NOT LEAP YEAR'
end as leap_or_not
from employee;

-- NEXT_DAY(date, day) -> return date that will be on that day of week coming next after given date

select next_day(sysdate, 'Wednesday') from dual;

-- Find the next frienship day

select next_day(to_date('31-Jul-26'), 'Sunday') from dual;

-- day before

select next_day(sysdate-8, 'Sunday') from dual;

-- AGGREGATE FUNCTIONS

-- count, sum, avg, min, max, variance, stddev

select count(employee_id), sum(salary), avg(salary), min(salary), max(salary) from hr.employees;

select variance(salary), stddev(salary) from hr.employees;

-- group by

select department_id, count(*), sum(salary) from employee group by department_id;

-- find department wise count of employees for departments whose total salary is more than 50000

select department_id, count(*) from employee
    group by department_id
    having sum(salary)>50000 and count(*)<10;

-- operation -> table -> where -> group by -> having -> projection

-- Find the count of employees by department and then by job_id
select department_id, job_id, count(*) from employee
    group by department_id, job_id;

-- Find the departments where number of employees are atleast 5
select department_id from employee group by department_id having count(*)>=5 order by department_id;

-- Find the count of employees by year of joining
select to_char(hire_date, 'YYYY') as yr, count(*) cnt from employee group by yr order by yr;


-- Converting SQL output to common data format like JSON and XML

-- XML

select DBMS_XMLGEN.GETXML('select * from student') from dual;

-- JSON
    -- JSON_ARRAYAGG, JSON_OBJECT

select employee_id, first_name, salary from employee where department_id=30;


select 
    JSON_ARRAYAGG(
        JSON_OBJECT(
            KEY 'Employee ID' VALUE employee_id,
            KEY 'First Name' VALUE first_name,
            KEY 'Salary' VALUE salary
        )
    ) as emp_json
from employee where department_id=30;


-- SUBQUERIES
    -- 

-- Find the employees who earn more than kimberely Grant;

select employee_id, first_name from employee where salary>(
    select salary from employee where first_name='Kimberely' and last_name='Grant'
);

-- Find all employees who are working in same department as Joshua Patel

select employee_id, first_name from employee where department_id=(
    select department_id from employee where first_name='Joshua' and last_name='Patel'
); 

-- Subqueries - single value, list, table, null

-- Find all employees who are also managers

select employee_id, first_name from employee where employee_id IN(
    select distinct manager_id from employee);


-- ANY -> return true if the match is found with atleast one element
-- ALL -> retur true if match is found with all elements

-- Find all employees who earn more than any manager

select * from employee where salary>ANY(
    select distinct salary from employee where employee_id IN(
        select distinct manager_id from employee where manager_id is not null))
    AND employee_id NOT IN(select distinct manager_id from employee where manager_id is not null);

-- Find all employees who earn less than all managers

select * from employee where salary<ALL(
    select distinct salary from employee where employee_id IN(
        select distinct manager_id from employee where manager_id is not null));


-- Find employees who earn more than average salary
select first_name, last_name, salary from employee
    where salary>(select avg(salary) from employee);

-- Find names of employee who earn maximum salary in their respective department

-- correlated subquery 
-- Top-N Analysis
select first_name, last_name, department_id, job_id, salary from employee e
    where salary=(
        select max(salary) from hr.employees where department_id=e.department_id
    ) order by department_id;

-- multirow subquery
select first_name, last_name, department_id, job_id, salary from employee e
    where (department_id, salary) IN(
        select department_id, max(salary) from employee group by department_id);


-- Find second highest salary earners in company

select first_name, salary from employee where salary=(
select salary from employee where salary<(select max(salary) from employee) fetch first 1 rows only);

-- coorelated method

select first_name, salary from employee e
    where 1=(select count(distinct salary) from employee where salary>e.salary);

-- Display employee name and salary along with max salary against each record

-- inline subquery
select first_name, salary, (select max(salary) from employee) max_salary from employee;

-- WITH operator & CTE

select first_name, salary from employee where salary>(select avg(salary) from employee);

WITH CTE(avgsal) as (select avg(salary) from employee)
select first_name, salary from employee, CTE
    where salary>CTE.avgsal;


-- Diplay the department and its minimum salary for the department that has maximum avg salary

select department_id, min(salary) from employee group by department_id
    having avg(salary)=(select max(avg(salary)) from employee group by department_id);

WITH CTE(mxavgsal) as (select max(avg(salary)) from employee group by department_id)
select department_id, min(salary) from employee, CTE group by department_id, CTE.mxavgsal
    having avg(salary)=CTE.mxavgsal;

-- Display the records for department 30 if there is atleast one employee who earn more than 10000

-- EXISTS 

select first_name, salary from employee where department_id=30 AND EXISTS (
    select * from employee where department_id=30 and salary>10000
);

select first_name, salary from employee where department_id=30 AND EXISTS (
    select * from employee where department_id=30 and salary>15000
);

-- JOINS

-- Implicit Joins
    -- implicit cross join
    select employee_id, first_name, last_name, salary, department_name from employee, department;
    -- employee=107, depart=27 => 107x27 => 2889

    -- implicit inner join
    select employee_id, first_name, last_name, salary, department_name from employee, department
        where employee.department_id=department.department_id;
    -- 106 records from left to right table mapping

-- Explicit Joins
    -- explicit cross join
    select employee_id, first_name, last_name, salary, department_name from employee CROSS JOIN department;
    
    -- explicit natural join
    select employee_id, first_name, last_name, salary, manager_id, department_id, department_name 
        from employee NATURAL JOIN department;

    -- inner join
    select employee_id, first_name, last_name, salary, department_name from employee INNER JOIN department
    ON employee.department_id=department.department_id;

    select employee_id, first_name, last_name, salary, department_name from employee JOIN department
    ON employee.department_id=department.department_id;

    select employee_id, first_name, last_name, salary, department_name from employee e JOIN department d
    ON e.department_id=d.department_id;

    -- outer join
        -- left
    select employee_id, first_name, last_name, salary, department_name from employee LEFT OUTER JOIN department
    ON employee.department_id=department.department_id;
    -- 106 + 01 (unmapped from left) = 107

    select employee_id, first_name, last_name, salary, department_name from employee LEFT JOIN department
    ON employee.department_id=department.department_id;

        -- right
    select employee_id, first_name, last_name, salary, department_name from employee RIGHT JOIN department
    ON employee.department_id=department.department_id;
    -- 106 + 16 (unmapped from right) = 122

        -- full
    select employee_id, first_name, last_name, salary, department_name from employee FULL JOIN department
    ON employee.department_id=department.department_id;
    -- 106 + 01 (unmaaped from left) + 16 (unmapped from right) = 123


-- ANTI-JOIN
    -- Retrieving only those record from left table which does not have mapping to right table

select employee_id, first_name, last_name, salary, department_name from employee LEFT JOIN department
    ON employee.department_id=department.department_id where employee.department_id is null;

select employee_id, first_name, last_name, salary, department_name from employee LEFT JOIN department
    ON employee.department_id=department.department_id
MINUS
select employee_id, first_name, last_name, salary, department_name from employee JOIN department
    ON employee.department_id=department.department_id;

select employee.* from employee where employee.department_id NOT IN (
    select department.department_id from department
);