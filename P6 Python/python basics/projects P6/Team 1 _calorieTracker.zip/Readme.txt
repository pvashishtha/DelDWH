/*
Project Title: Calorie Intake Tracker
By: Aman Sharma, Anisha Pandey. Sehajpreet Singh Oberoi
(USI Gurgaon Office)

This zip file contains 3 files:
1. team1_calorieTracker.ipynb (Jupyter Notebook Format) - It consists of the source code for the Calorie Intake Tracker Project based on the learning from Python Basics training.

2. food_cal_info.csv - This is the reference file for the data extraction for calculation of calorie intake of the User. The format of the file is <food_item>,<calorie>. The data mentioned is as per 100g comsumption

3. Readme.txt

*/