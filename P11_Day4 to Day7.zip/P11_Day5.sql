-- Exception Handling
    -- User-Defined Exceptions
        -- Declare exception -> associate with code and message -> conditional raise -> handler

DECLARE
    low_salary EXCEPTION;
    v_salary employee.salary%TYPE;
    v_msg varchar(100);
BEGIN
    select salary into v_salary from employee where employee_id=105;
    if v_salary<25000 then
        v_msg:='This salary is too low for the type employee';
        RAISE low_salary;
    end if;
EXCEPTION
    when low_salary then
        RAISE_APPLICATION_ERROR(-20100, v_msg);
    when others then
        dbms_output.put_line('Some other error.');
END;

-- Write code with user defined exception to check at time of update the value of email must contain @ symbol and
    -- a proper domain name after it

declare
    email_update_err EXCEPTION;
    v_eid int :=400;
    v_email varchar(100);
begin
    v_email:=&EnterEMAIL;
    if regexp_like(v_email, '^[A-Za-z0-9]+@[A-Za-z0-9]+\.[A-Za-z]+$') then
        update employee set email=v_email where employee_id=v_eid;
        commit;
        v_eid:=230/0;
    else
        RAISE email_update_err;
    end if;
exception
    when email_update_err then
        RAISE_APPLICATION_ERROR(-20099, 'Email is not as per standard validation norms.');
    when others then
        dbms_output.put_line(SQLCODE || ' ' || SQLERRM);
end;

select * from employee where employee_id=400;

-- Write code to simulate integrity constraint error and print its error code and message using built-in attributes

CREATE TABLE employee10 (
    emp_id NUMBER PRIMARY KEY,
    emp_name VARCHAR2(50)
);

BEGIN
    -- First insert (valid)
    INSERT INTO employee10 VALUES (101, 'John');
    -- Second insert with same primary key (will cause error)
    INSERT INTO employee10 VALUES (101, 'Smith');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error Code: ' || SQLCODE);
        DBMS_OUTPUT.PUT_LINE('Error Message: ' || SQLERRM);
END;

-- CURSOR
DECLARE
    CURSOR cur IS select * from employee where department_id=30;
    v_rec employee%ROWTYPE;
BEGIN
    OPEN cur;
        LOOP
        FETCH cur INTO v_rec;
        EXIT WHEN cur%NOTFOUND;
        dbms_output.put_line(v_rec.first_name||' earns '||to_char(v_rec.salary, '$999,999,999.99'));
        END LOOP;
    dbms_output.put_line('Rows Fetched: '||cur%ROWCOUNT);
    CLOSE cur;
END;

-- Write code to fetch data through cursor from a department mentioned by user. Display maximum 5 records of any dept

DECLARE
    CURSOR cur(p_dept integer) IS select * from employee where department_id=p_dept;
    v_rec employee%ROWTYPE;
    v_dept int;
BEGIN
    v_dept:=&EnterDept;
    OPEN cur(v_dept);
        LOOP
        FETCH cur INTO v_rec;
        EXIT WHEN cur%ROWCOUNT>5 OR cur%NOTFOUND;
        dbms_output.put_line(v_rec.first_name||' earns '||to_char(v_rec.salary, '$999,999,999.99'));
        END LOOP;
    dbms_output.put_line('Rows Fetched: '||cur%ROWCOUNT);
    CLOSE cur;
END;

--

DECLARE
    CURSOR cur(p_dept integer, p_job varchar) 
        IS select count(*) from employee where department_id=p_dept and job_id=p_job;
   v_count integer default 0;
BEGIN
    OPEN cur(80, 'SA_REP');
        LOOP
        FETCH cur INTO v_count;
        EXIT WHEN cur%NOTFOUND;
        dbms_output.put_line('Count Sales Representatives: '||v_count);
        END LOOP;
    CLOSE cur;
    OPEN cur(80, 'SA_MAN');
        LOOP
        FETCH cur INTO v_count;
        EXIT WHEN cur%NOTFOUND;
        dbms_output.put_line('Count Sales Manager: '||v_count);
        END LOOP;
    CLOSE cur;
    OPEN cur(60, 'IT_PROG');
        LOOP
        FETCH cur INTO v_count;
        EXIT WHEN cur%NOTFOUND;
        dbms_output.put_line('Count Programmers: '||v_count);
        END LOOP;
    CLOSE cur;
END;

-- Cursor with subquery
    -- Write code using cursor to find all employees who are also managers
DECLARE
    CURSOR cur IS select * from employee where employee_id IN(
        select distinct manager_id from employee where manager_id is not null
    );
    v_rec employee%ROWTYPE;
BEGIN
    OPEN cur;
    loop
        FETCH cur into v_rec;
        exit when cur%notfound;
        dbms_output.put_line('Name: '||concat(concat(v_rec.first_name, ' '), v_rec.last_name));
    end loop;
END;

-- Using FOR loop with cursor

DECLARE
    CURSOR cur IS select * from employee where job_id='IT_PROG';
    v_rec employee%ROWTYPE;
BEGIN
    FOR v_rec IN cur LOOP    
        dbms_output.put_line(v_rec.employee_id||' '||v_rec.first_name);
    END LOOP;
END;

-- Adv Cursor concept
    -- FOR UPDATE <col> NOWAIT -> apply lock on records fro update operation
    -- WHERE CURRENT OF cursor -> perform operation at current cursor pointer record in active set

DECLARE
    CURSOR cur IS select * from employee where department_id=80 and job_id='SA_MAN' FOR UPDATE OF salary NOWAIT;
    emprec employee%ROWTYPE;
BEGIN
    for emprec in cur loop
        if emprec.salary<50000 then
            update employee set salary=emprec.salary*1.5 WHERE CURRENT OF cur;
            commit;
        end if;
    end loop;
END;

select * from employee where department_id=80 and job_id='SA_MAN';

-- REF cursor

-- weak ref cursor

DECLARE
    TYPE emp_cur_type IS REF CURSOR;
    emp_cur emp_cur_type;
    emprec employee%rowtype;
BEGIN
    dbms_output.put_line('FOR 2015');
    OPEN emp_cur FOR select * from employee where to_char(hire_date, 'YYYY')='2015';
    loop
        FETCH emp_cur into emprec;
        EXIT when emp_cur%notfound;
        dbms_output.put_line(emprec.first_name);
    end loop;
    close emp_cur;
    -- for year 2016
    dbms_output.put_line('FOR 2016');
    OPEN emp_cur FOR select * from employee where to_char(hire_date, 'YYYY')='2016';
    loop
        FETCH emp_cur into emprec;
        EXIT when emp_cur%notfound;
        dbms_output.put_line(emprec.first_name);
    end loop;
    close emp_cur;
END;

-- strong ref cursor- return type

DECLARE
    emp_rec employee%rowtype;
    TYPE cur_type IS REF CURSOR return employee%rowtype;
    cur cur_type;
BEGIN
    open cur for select * from employee where department_id=20;
    LOOP    
        fetch cur into emp_rec;
        exit when cur%notfound;
        dbms_output.put_line(emp_rec.job_id);
    END LOOP;
END;

-- weak type exmaple

DECLARE
    emp_rec department%rowtype;
    TYPE cur_type IS REF CURSOR;
    cur cur_type;
BEGIN
    open cur for select * from department where department_id=20;
    LOOP    
        fetch cur into emp_rec;
        exit when cur%notfound;
        dbms_output.put_line(emp_rec.department_name);
    END LOOP;
END;

-- Create a weak ref cursor that reads products and price of product from products table and same cursor 
    -- reading sales table to get total number of sale records

DECLARE
    type cur_type is ref cursor;
    cur cur_type;
    rec products%rowtype;
    v_count number;
BEGIN
    open cur for select * from products;
    loop
        fetch cur into rec;
        exit when cur%notfound;
        dbms_output.put_line(rec.pname||' '||rec.price);
    end loop;
    close cur;
    open cur for select count(*) from sales;
    loop
        fetch cur into v_count;
        exit when cur%notfound;
        dbms_output.put_line('Total Records of Sale: '||v_count);
    end loop;
    close cur;
END;

-- Create strong cursor that reads locations table records only. Read city names and dsiplay. Use same 
    -- to get zip codes listed.

DECLARE
    TYPE cur_type IS REF CURSOR return hr.locations%rowtype;
    cur cur_type;
    v_rec hr.locations%rowtype;
BEGIN
    open cur for select * from hr.locations;
    loop
        fetch cur into v_rec;
        exit when cur%notfound;
        dbms_output.put_line(v_rec.city);
    end loop;
    close cur;
    open cur for select * from hr.locations where city='Seattle';
    loop
        fetch cur into v_rec;
        exit when cur%notfound;
        dbms_output.put_line(v_rec.postal_code);
    end loop;
    close cur;
END;

-- SUBPROGRAMS
    -- Named PLSQL block
    -- Mainly: Procedure & Function
    -- Stored like schema objects
    -- modularity, reusability, maintenance, secure, performance
/*
-- subprogram specification
HEADER (procedure | function, parameter list, local variables)

-- subprogram body
BEGIN

EXCEPTION

END;
*/

-- PROCEDURE

create or replace procedure p1 is
begin
    dbms_output.put_line('Hello World from Procedure!!!');
end;

select * from user_procedures;

exec p1;

desc p1;

drop table employee;

create or replace procedure recreate_employee is
begin
    create table employee as select * form hr.employees;
end;

create table employee as select * from hr.employees;

-- perform DML operation

create or replace procedure update_salary is
begin
    update employee set salary=salary*1.1 where salary<5000;
    dbms_output.put_line(SQL%ROWCOUNT);
    commit;
end;

exec update_salary;

-- procedure with parameters
    -- IN => used to accept input values at time of procedure call
    -- OUT => used to return output values generated at runtime
    -- IN OUT => used as both input and output parameter

create or replace procedure find_salary(p_dept IN integer) is
v_sal number :=0;
begin
    select sum(salary) into v_sal from employee where department_id=p_dept;
    dbms_output.put_line('Total Salary: '||v_sal);
end;

exec find_salary(50);

create or replace procedure find_salary(p_dept IN integer, p_total_salary OUT number) is
begin
    select sum(salary) into p_total_salary from employee where department_id=p_dept;
end;

declare
    v_tot_sal number;
begin
    find_salary(60, v_tot_sal);
    dbms_output.put_line('Total Salary: '||v_tot_sal);
end;

-- IN OUT

create or replace procedure process_string(str IN OUT varchar) is
begin
    str:=upper(str);
    str:=replace(str, 'A', '@');
    if NOT substr(str, -1, 1) = '.' then
        str:=concat(str, '.');
    end if;
end;

declare
    v_str varchar(100) default 'hello all';
begin
    v_str:='plsq is a useful language';
    process_string(v_str);
    dbms_output.put_line(v_str);
end;


-- create a procedure that accepts amount and acc number. It must check for account balance to allow debit.
    -- if account balance after debit goes below 1000 then it must ot allow debit, else allow and update account

create or replace procedure debit_account(p_accno IN number, p_amount IN number) is
v_balance number;
begin
    select acc_balance into v_balance from accounts where acc_nu=p_accno;
    if (v_balance-p_amount)<1000 then
        dbms_output.put_line('Debit not allowed, insufficeint balance.');
        dbms_output.put_line('Account Number: '||p_accno);
        dbms_output.put_line('Current Balance: '||v_balance);
    else
        update accounts set acc_balance=acc_balance-p_amount where acc_nu=p_accno;
        dbms_output.put_line('Debit Successful!');
        dbms_output.put_line('Account Number: '||p_accno);
        dbms_output.put_line('Current Balance: '||(v_balance-p_amount));
    end if;
end;

exec debit_account(1006, 300);


-- Create a global temporary table named employee_summary with fields like employee_id, first_name, salary,
    -- department id and job id

drop table employee_summary;

create global temporary table employee_summary(employee_id int, first_name varchar2(20), last_name varchar2(20),
    salary number, department_id int, job_id varchar2(10));


-- Create a procedure that accepts department id and job id as input. Then procedure must be able to insert data
    -- into temporary table related to given department and job id. Finally calculate the total salary, 
    -- average, min, max salary and print on console for given dept and job id.
create or replace procedure get_employee_summary(p_dept IN integer, p_job IN varchar) is
v_total number;
v_avg number;
v_min number;
v_max number;
begin
    insert into employee_summary select employee_id, first_name, last_name, salary, department_id, job_id
        from employee where department_id=p_dept and job_id=p_job;
    select sum(salary), avg(salary), min(salary), max(salary) into v_total, v_avg, v_min, v_max
        from employee_summary;
    dbms_output.put_line('Department: '||p_dept);
    dbms_output.put_line('Job: '||p_job);
    dbms_output.put_line('Total Salary: '||v_total);
    dbms_output.put_line('Average Salary: '||v_avg);
    dbms_output.put_line('Minimum Salary: '||v_min);
    dbms_output.put_line('Maximum Salary: '||v_max);   
end;

exec get_employee_summary(80, 'SA_MAN');


-- Named Parameters in procedure

create or replace procedure show_name_msg(init varchar, greet varchar default 'Good Morning', myname varchar) is
begin
    dbms_output.put_line(init||' '||greet||' '||myname||', Welcome to PLSQL Session.');
end;

exec show_name_msg('Good Morning', 'Prateek'); -- calling by positional arguments

-- calling by argument keyword

exec show_name_msg('Hi,', myname => 'Ayush', greet => 'Good Evening');

exec show_name_msg('Hi,', myname => 'Ayush');

-- Create a procedure that updates salary of specific employee and also add a log to log table using sub procedure

create table emp_log(logid int primary key, logtext varchar2(256), logdate date);

create sequence logseq start with 1001 increment by 1 minvalue 1000 nomaxvalue nocycle nocache;

create or replace procedure update_emp_salary(p_eid int, p_salary number) is
begin
    update employee set salary=p_salary where employee_id=p_eid;
    commit;
    -- inner block
    begin
        insert into emp_log values(logseq.nextval, 'Salary updated for '||p_eid||' by '||user, sysdate);
        commit;
    end;
end;

exec update_emp_salary(100, 28000);

select * from employee;
select * from emp_log;

-- Create a procedure update_email that accepts email from user for specific employee and uupdate it to
    -- employee table. Before update it calls another proceudre to check whether the email provided is 
    -- valid or not i.e. contains '@' and valid domain structure. If other procedure returns boolean true,
    -- it will update else give error message.

create or replace procedure validate_employee_email(p_email varchar, p_validity OUT boolean) is
begin
    p_validity:= regexp_like(p_email, '^[A-Za-z0-9]+@[A-Za-z0-9]+\.[A-Za-z]+$');
end;

create or replace procedure update_email(p_email varchar, p_eid int) is
v_validity boolean;
begin
    validate_employee_email(p_email, v_validity);
    if v_validity then
        update employee set email=p_email where employee_id=p_eid;
        commit;
        dbms_output.put_line('Email Updated for employee id: '||p_eid);
    else
        dbms_output.put_line('Invalid email, update failed!');
    end if;
end;

exec update_email('employee102dmail.com', 102);

-- Functions
    -- User Defined Functions
    -- perform specific tasks
    -- IN type args
    -- must return a value
    -- func can call other funcs
    -- func can be called from procedure
    -- func can not call procedure
    -- func can be part of expressions

create or replace function find_square(p_num IN number) return number is
begin
    return p_num**2;
end;

declare
    v_number number default 0;
    v_sqr number default 0;
begin
    v_number:=9;
    v_sqr:=find_square(v_number);
    dbms_output.put_line('Square of '||v_number||' is:'||v_sqr);
end;


begin
    dbms_output.put_line('Square of 9 is: '||find_square(9));
end;

select find_square(9) from dual;

select salary, find_square(salary) from employee;

select employee_id, salary from employee where salary<find_square(salary);


-- Write a function that can be used in SQL statements to find the tax over salary as per given slab:
    -- salary between 2000 and 10000 tax@10%
    -- saalry between 10001 and 20000 tax@20%
    -- Above 20000 tax@30%

create or replace function get_tds(p_salary IN number) return number is
begin
    if p_salary between 2000 and 10000 then
        return p_salary*0.10;
    elsif p_salary between 10001 and 20000 then
        return p_salary*0.20;
    elsif p_salary>20000 then
        return p_salary*0.30;
    else
        return 0;
    end if;
end;

select employee_id, first_name, salary, get_tds(salary) as tax from employee;

-- Write procedure that reads data from department table. It accepts department id and returns department name.
    -- if department id does not exist, it must handle exception to display message. Else it will display
    -- department details. Also, create a fucntion that will convert department name to upper case and 
    -- perform cleaning of name by trimming white spaces and extra characters like '!@#$%^&*~|'
    -- This procedure must read data into cursor and parse through cursor to diplay the value.

create or replace function convert_dept_str(str in varchar) return varchar is
begin
    return upper(trim(rtrim(ltrim(str, '~!@#$%^&*|'), '~!@#$%^&*|')));
end;

create or replace procedure get_department_name(p_dept IN integer) is
    CURSOR cur(dept_id integer) is select department_name from department where department_id=dept_id;
    v_deptname varchar(20);
begin
    OPEN cur(p_dept);
    LOOP
        FETCH cur into v_deptname;
        EXIT WHEN cur%NOTFOUND;
        dbms_output.put_line('Department ID: '||p_dept);
        dbms_output.put_line('Department Name: '||convert_dept_str(v_deptname));
    END LOOP;
    CLOSE cur;
end;


exec get_department_name(70);