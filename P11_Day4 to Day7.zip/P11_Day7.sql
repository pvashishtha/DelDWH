-- Write a PLSQL code to create a package "math_operations" that includes functions to calculate factorial of number
    -- and find whether gievn number is prime or not. It should have procedure that will invoke these functions
    -- on user demand and supply inputs. Procedure has to receive outptu and display on console.

-- Write a function code "get_invoice_number" that generates a sequential value to be used with table primary key, 
    --values must be in format like INV001, INV002, INV003 and so on.

-- Write PLSQL procedure code to fetch all employees from specific department and salary range and dsiplay
    -- ID, Name, Salary in aligned table format.

--
-- RECORD TYPE

DECLARE
    TYPE employee_minimal_record IS RECORD(
        empid int,
        fname varchar2(20),
        lname varchar2(20),
        salary number,
        dept int
    );
    emp employee_minimal_record;
    CURSOR cur is select employee_id, first_name, last_name, salary, department_id from employee 
        where department_id=30;
BEGIN
    open cur;
    LOOP
        fetch cur into emp;
        exit when cur%notfound;
        dbms_output.put_line(emp.empid||' '||emp.fname);
    END LOOP;
    close cur;
END;

DECLARE
    TYPE employee_minimal_record IS RECORD(
        empid int,
        fname varchar2(20),
        lname varchar2(20),
        salary number,
        dept int
    );
    emp employee_minimal_record;
BEGIN
    emp.empid:=301;
    emp.fname:='John';
    emp.lname:='Doe';
    emp.salary:=34000;
    emp.dept:=90;
    insert into employee(employee_id, first_name, last_name, salary, department_id)
        values(emp.empid, emp.fname, emp.lname, emp.salary, emp.dept);    
END;

-- Create table books with attributes like book_id, book_title, book_author, book_release_date
-- create a PLSQL block with custom record to enter data in book

create table book(bood_id int, book_title varchar2(50), book_author varchar2(20), book_release_date date);

DECLARE
    TYPE book_data_type IS RECORD(
        id int, title varchar2(50), author varchar2(20), release_date date
    );
    newbook book_data_type := book_data_type(5001, 'The best book', 'Jennifer', '13-Jan-24');
BEGIN
    insert into book values newbook;
END;

DECLARE
    TYPE book_data_type IS RECORD(
        id int, title varchar2(50), author varchar2(20), release_date date
    );
    newbook book_data_type;
BEGIN
    newbook.id:=&EnterBookID;
    newbook.title:=&EnterTitle;
    newbook.author:=&EnterAuthor;
    newbook.release_date:=&EnterDate;
    insert into book values newbook;
END;

select * from book;

-- Procedures with Autonomous Transactions
    -- An independent transaction that can be commited or rollbacked without affecting main transaction

create table book_log(logid int, log_desc varchar2(256), logstamp timestamp);

alter table book_log add constraint logid_pk primary key(logid);

create sequence book_log_seq start with 1001 increment by 1 nominvalue nomaxvalue nocache nocycle;

-- create autonomous logging procedure
create or replace procedure book_logging(p_logmsg IN varchar2) is
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    insert into book_log values(BOOK_LOG_SEQ.nextval, p_logmsg, systimestamp);
    commit;
EXCEPTION
    when others then rollback;
END;

-- main transaction block
DECLARE
    v_dummy number;
BEGIN
    -- successful transaction
    insert into book_log values(book_log_seq.nextval, 'This is from main transaction block', systimestamp);
    -- fail this insert transaction
    insert into book_log values(1001, 'This is also trial from main transaction block', systimestamp);
EXCEPTION
    when others then book_logging('Error trapped in main block: '||SQLERRM);
    rollback;
END;

select * from book_log;

-- Create an autonomous transaction procedure for employee table that enters log to log table.
    -- Create a transaction block that updates employee table and on exception will rollback update
    -- demonstrate autonomous transactoin logging on rollback

---

-- object oriented programming
    -- class => attributes and methods

-- OBJECT
    -- user-defined composite datatype that encapsulates data attributes and methods(procedure & function)
    -- default constructor
    -- define custom constructors also
    -- supports inheritance -> single inheritance

create type book_type AS OBJECT(
    id int, title varchar2(50), author varchar2(20), release_date date);

DECLARE
    book_details book_type; -- creating object variable
BEGIN
    book_details:=book_type(90, 'Five point someone', 'chetan bhagat', '14-Feb-06'); -- default constructor
    insert into book values(book_details.id, book_details.title, book_details.author, book_details.release_date);
    dbms_output.put_line(book_details.title);
END;

select * from book;

-- OBJECT type with function and procedure

create or replace type book_data_type as OBJECT(
    id int, title varchar2(50), author varchar2(20), release_date date,
    member procedure add_book_details(p_id int, p_title varchar2, p_author varchar2, p_release_date date),
    member function clean_str(p_str varchar2) return varchar2,
    member procedure display_all_books
);

create or replace type body book_data_type as
    member function clean_str(p_str varchar2) return varchar2 is
    begin
        return trim(upper(p_str));
    end;

    member procedure add_book_details(p_id int, p_title varchar2, p_author varchar2, p_release_date date) is
    begin
        insert into book values(p_id , p_title , p_author , p_release_date );
        commit;
    exception
        when others then rollback;
    end;

    member procedure display_all_books is
        cursor cur is select * from book;
    begin
        for rec in cur loop
            dbms_output.put_line('Book ID: '||rec.book_id);
            dbms_output.put_line('Book Title: '||rec.book_title);
            dbms_output.put_line('Book Author: '||rec.book_author);
            dbms_output.put_line('Book Release Date: '||rec.book_release_date);
        end loop;
    end;
end;

-- usage of object type and object variable

declare
    book_data book_data_type;
begin
    book_data:=book_data_type(5006, ' Financial Planning  ', ' Bishal Ben ', '10-Aug-08');

    book_data.add_book_details(book_data.id, book_data.clean_str(book_data.title), 
        book_data.clean_str(book_data.author), book_data.release_date);

    book_data.display_all_books;
end;

select * from book;

-----------------------

-- DYNAMIC SQL
create or replace procedure dynamic_truncate(tablename varchar2) is
BEGIN
    EXECUTE IMMEDIATE 'truncate table '||tablename;
END;

select * from employee;

exec DYNAMIC_TRUNCATE('employee');

-- delete conditionally

create or replace procedure delete_conditionally(tablename varchar, condition varchar) is
begin
    execute immediate 'delete from '||tablename||' '||condition;
    dbms_output.put_line(SQL%ROWCOUNT||' Row(s) Deleted.');
    commit;
exception
    when others then rollback;
end;

exec DELETE_CONDITIONALLY('employee', 'where department_id=30');

select * from employee where department_id=30;

-- DBMS_SQL example
create table new_emp(empno int, ename varchar2(20), sal number, dept int);

create sequence empseq;

create or replace procedure new_emp_entry(ename varchar, sal number, dept int) is
begin
    insert into new_emp values(empseq.nextval, ename, sal, dept);
    commit;
end;

-- DBMS_SQL Native

declare
    c integer;
    n number;
begin
    c:=DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(c, 'BEGIN new_emp_entry(:a, :b, :c); END;', DBMS_SQL.NATIVE);
    DBMS_SQL.BIND_VARIABLE(c, ':a', 'Prateek');
    DBMS_SQL.BIND_VARIABLE(c, ':b', '78000');
    DBMS_SQL.BIND_VARIABLE(c, ':c', 90);
    n:=DBMS_SQL.EXECUTE(c);
    DBMS_SQL.CLOSE_CURSOR(c);
end;


select * from new_emp;