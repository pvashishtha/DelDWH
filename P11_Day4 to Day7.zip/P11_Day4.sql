-- Find the employees who earn second highest salary in company. [Hint: Use Analytical Function]

select first_name, salary from(
select first_name, salary, dense_rank() over(order by salary desc) as drnk from employee)
    where drnk=2;

-- PLSQL

-- block
/*
DECLARE 
    -- declaration section
BEGIN
    -- execution section
EXCEPTION
    -- exception handling section
END;
*/

-- Example execution with variables
-- unnamed procedure/ anonymous procedure block

DECLARE
    myname varchar(20);
BEGIN
    myname := 'Prateek';
    -- display
    DBMS_OUTPUT.PUT_LINE(myname);
END;    

-- variable declarations

DECLARE
    x integer;
    y number :=3.14;
    z int default 0;
BEGIN
    x:=10;
    z:=20;
    DBMS_OUTPUT.PUT_LINE('X = '||x);
    DBMS_OUTPUT.PUT_LINE('Y = '||y);
    DBMS_OUTPUT.PUT_LINE('Z = '||z);
END;

DECLARE
    x integer;
    y number :=3.14;
    z int default 0;
BEGIN
    x:=10;
    z:=20;
    DBMS_OUTPUT.PUT_LINE('X = '||x||' Y = '||y||' Z = '||z);
END;

-- PUT_LINE with CHR(10) for new line
DECLARE
    x integer;
    y number :=3.14;
    z int default 0;
BEGIN
    x:=10;
    z:=20;
    DBMS_OUTPUT.PUT_LINE('X = '||x||CHR(10)||' Y = '||y||CHR(10)||' Z = '||z);
END;

-- PUT example
BEGIN
    DBMS_OUTPUT.PUT('Hello ');
    DBMS_OUTPUT.PUT('World! ');
    DBMS_OUTPUT.PUT('How are ');
    DBMS_OUTPUT.PUT_LINE('you? ');
END;

-- Write PLSQL block to create a pyramid of * symbols using PUT and PUT_LINE only

BEGIN
    DBMS_OUTPUT.PUT('    *'||CHR(10));
    DBMS_OUTPUT.PUT('   * *'||CHR(10));
    DBMS_OUTPUT.PUT('  * * *'||CHR(10));
    DBMS_OUTPUT.PUT(' * * * * '||CHR(10));
    DBMS_OUTPUT.PUT_LINE('* * * * *');
END;

-- SQL Integration
DECLARE
    v_dept employee.department_id%TYPE;
BEGIN
    v_dept:=50;
    update employee set salary=salary/2 where department_id=v_dept;
    DBMS_OUTPUT.PUT_LINE('Rows Updated: '||SQL%ROWCOUNT);
    commit;
END;

select * from employee where department_id=30;

-- SQL output can be managed in variable

DECLARE
    v_eid employee.employee_id%TYPE default 100;
    v_salary employee.salary%TYPE;
BEGIN
    v_eid:=108;
    select salary into v_salary from employee where employee_id=v_eid;
    DBMS_OUTPUT.PUT_LINE('Salary for EID: '||v_eid||' is: '||v_salary);
END;

-- Using PLSQL block, find and display the total and average salary for all employees

DECLARE
    v_total number;
    v_average number;
BEGIN
    select sum(salary), round(avg(salary),2) into v_total, v_average from employee;
    DBMS_OUTPUT.PUT('Total Salary: '||v_total||CHR(10));
    DBMS_OUTPUT.PUT_LINE('Average Salary: '||v_average);
END;

-- Composite Variable -> contains multiuple values of same or diff type

DECLARE
    v_record employee%ROWTYPE;
BEGIN
    select * into v_record from employee where employee_id=100;
    DBMS_OUTPUT.PUT_LINE('First Name: '||v_record.first_name);
    DBMS_OUTPUT.PUT_LINE('Last Name: '||v_record.last_name);
    DBMS_OUTPUT.PUT_LINE('Salary: '||v_record.salary);
    DBMS_OUTPUT.PUT_LINE('Job Role: '||v_record.job_id);
END;

-- Write PLSQL block to read employee 127 data and display name and current salary, also salary after 20% hike.
DECLARE
    v_rec employee%ROWTYPE;
    v_eid integer :=127;
BEGIN
    select * into v_rec from employee where employee_id=v_eid;
    DBMS_OUTPUT.PUT_LINE('First Name: '||v_rec.first_name);
    DBMS_OUTPUT.PUT_LINE('Last Name: '||v_rec.last_name);
    DBMS_OUTPUT.PUT_LINE('Salary: '||v_rec.salary);
    v_rec.salary:=v_rec.salary*1.2;
    DBMS_OUTPUT.PUT_LINE('Updated Salary: '||v_rec.salary);
END;

-- Write PLSQL block to find the details of employee for user provided employee ID and dislplay its name and job id
    -- in upper case letter

DECLARE
    v_eid integer default 100;
    v_record employee%ROWTYPE;
BEGIN
    v_eid := '&Enter_EID_of_Employee';
    select * into v_record from employee where employee_id=v_eid;
    DBMS_OUTPUT.PUT_LINE('First Name: '||upper(v_record.first_name));
    DBMS_OUTPUT.PUT_LINE('Last Name: '||upper(v_record.last_name));
    DBMS_OUTPUT.PUT_LINE('Salary: '||v_record.salary);
    DBMS_OUTPUT.PUT_LINE('Job Role: '||upper(v_record.job_id));
END;

-- Nested Blocks and Varibale Scope

DECLARE
    var_x number :=10;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Outer Var X= '||var_x); -- accesible
    DECLARE
        var_y number :=20; -- local
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Inner Var X= '||var_x); -- accesible
        DBMS_OUTPUT.PUT_LINE('Inner Var Y= '||var_y); -- accesible
    END;
    -- DBMS_OUTPUT.PUT_LINE('Outer Var Y= '||var_y); -- not accesible
END;

-- where outer and inner block has same variable name

<<global>>
DECLARE
    var_x number :=10;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Outer Var X= '||var_x); -- accesible
    DECLARE
        var_x number :=20; -- local
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Local Var X= '||var_x); -- local preferred over global
        DBMS_OUTPUT.PUT_LINE('Global Var X= '||global.var_x); -- accesible with label
    END;
END;

-- Operator => ** used for exponential
DECLARE
    x number :=5;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Square of X: '||x**2);
END;

-- Conditional Statements


-- Write PLSQL Block to accept a number from user and print the number if only it is single digit.
declare
    num number;
begin
    num:=&enter_number;
    if num between 1 and 9 then
        dbms_output.put_line('Single Digit Number: '||num);
    end if;
    dbms_output.put_line('*** End of Code ***');
end;

-- Write a PLSQL block code to find salary of employee for given EID and determine whether it is high salary
    -- or low salary based on whether it is more than 15000 or not.

declare
    v_eid number default 100;
    v_salary number;
begin   
    v_eid := &enter_EID;
    select salary into v_salary from employee where employee_id=v_eid; 
    if v_salary>=15000 then
        dbms_output.put_line('High Salary');
    else 
        dbms_output.put_line('Low Salary');
    end if;
end;

-- Write PLSQL code that accepts student marks out of 500. Calculate the percentage and evaluate grade on percent as:
    -- 90 to 100 => Grade A
    -- 75 to 89  => Grade B
    -- 60 to 74  => Grade C
    -- 40 to 59  => Grade D
    -- Below 40  => Grade E
    -- Invalid value => Invalid

declare
    marks number default 0;
    percent number default 0;
begin
    marks := &EnterMarks;
    percent:=round((marks/500)*100,2);
    dbms_output.put_line('Total Marks: '||marks);
    dbms_output.put_line('Percentage: '||percent);
    if percent between 90 and 100 then
        dbms_output.put_line('Grade A');
    elsif percent between 75 and 89 then
        dbms_output.put_line('Grade B');
    elsif percent between 60 and 74 then
        dbms_output.put_line('Grade C');
    elsif percent between 40 and 59 then
        dbms_output.put_line('Grade D');
    elsif percent between 0 and 39 then
        dbms_output.put_line('Grade E');
    else
        dbms_output.put_line('Invalid Marks');
    end if;
end;

-- Implement above example using CASE in PLSQL block

declare
    marks number default 0;
    percent number default 0;
    grade char(20);
begin
    marks := &EnterMarks;
    percent:=round((marks/500)*100,2);
    dbms_output.put_line('Total Marks: '||marks);
    dbms_output.put_line('Percentage: '||percent);
    grade:=
    CASE
    when percent between 90 and 100 then 'Grade A'
    when percent between 75 and 89 then 'Grade B'
    when percent between 60 and 74 then 'Grade C'
    when percent between 40 and 59 then 'Grade D'
    when percent between 0 and 39 then 'Grade E'
    else 'Invalid Marks'
    end;
    dbms_output.put_line(grade);
end;

-- Write PLSQL code that accepts department id from user, fetches the average salary of the department.
    -- Then it must check average of department with average of all employees and determine whether it is 
    -- less than avg or more. Based on that, if it is less than average of all employees then update salaries
    -- of that department employees by 25% hike. else, update by 10% hike only.

declare
    v_dept employee.department_id%TYPE;
    v_avgdept number default 0;
    v_avgall number default 0;
    factor number default 1;
begin
    v_dept:=&Enter_Department_ID;
    select avg(salary) into v_avgdept from employee where department_id=v_dept;
    select avg(salary) into v_avgall from employee;
    if v_avgdept < v_avgall then
        factor:=1.25;
    else 
        factor:=1.10;
    end if;
    dbms_output.put_line('Factor: '||factor);
    update employee set salary=salary*factor where department_id=v_dept;
    commit;
end;

-- Create a table accounts with following attributes: accno, acc_name, acc_balance, acc_type. Enter 5 records.

-- Write PLSQL code that accepts amount from user and checks ths balance for specific account number provided.
    -- in case, balance after debit will be less than 500, it will print message that account can not be debited
    -- otherwise, updates the balance to new balance after debit of amount.

drop table accounts;

create table accounts(acc_nu int primary key, acc_name varchar2(20), acc_balance number, acc_type varchar2(10));
insert into accounts values(1001, 'Prateek', 700, 'SA');
insert into accounts values(1002, 'Aditi', 2300, 'SA');
insert into accounts values(1003, 'Saksham', 1600, 'SA');
insert into accounts values(1004, 'Simant', 2850, 'SA');
insert into accounts values(1005, 'Sanjay', 900, 'SA');
insert into accounts values(1006, 'Kriti', 2600, 'CA');


declare
    accno integer :=1001;
    amount number :=0;
    balance number default 0;
begin
    accno:=&EnterAccount;
    amount:=&EnterAmount;
    select acc_balance into balance from accounts where acc_nu=accno;
    if balance-amount <500 then 
        dbms_output.put_line('Debit Not Possible. Insufficient Balance');
    else 
        update accounts set acc_balance=acc_balance-amount where acc_nu=accno;
        dbms_output.put_line('Amount Debited: '||amount);
        dbms_output.put_line('Current Balance: '||(balance-amount));
        commit;
    end if;
end;

select * from accounts;

-- LOOP Control

-- Basic Loop

/*
LOOP
-- statements
EXIT WHEN Condition
END LOOP;
*/

declare 
    v_iter integer :=0;
begin
    LOOP    
        dbms_output.put_line('Iter: '||v_iter);
        v_iter:=v_iter+1;
        EXIT WHEN v_iter>5;
    END LOOP;
end;

-- Using basic loop, display all names from employee ID 120 to 125
declare
    iter integer :=120;
    name varchar(20);
begin
    loop
        select first_name into name from employee where employee_id=iter;
        dbms_output.put_line(name);
        iter:=iter+1;
        exit when iter>125;
    end loop;
end;

-- Using basic loop, generate first N even numbers
declare
    iter integer :=1;
    num integer;
    counter integer :=0;
begin
    num:=&EnterNumber;
    loop
        if mod(iter,2)=0 then
            counter:=counter+1;
            dbms_output.put_line(iter);
        end if;
        iter:=iter+1;
        exit when counter>=num;
    end loop;
end;

-- Using basic loop, find the factorial of a gievn number
declare
    num integer:=0;
    fact number:=1;
    iter integer:=0;
begin
    num:=&EnterNumber;
    loop
        iter:=iter+1;
        fact:=fact*iter;
    exit when iter>=num;
    end loop;
    dbms_output.put_line('Factorial of '||num||' is: '||fact);
end;

-- Using loop over department ID, find the total salary for departments 10,20,30,40,50

declare
    sal number;
    iter integer:=0;
begin
    loop
        iter:=iter+10;
        select sum(salary) into sal from employee where department_id=iter;
        dbms_output.put_line('Total Salary for department '||iter||' is '||sal);
    exit when iter>=50;
    end loop;
end;

-- While Loop

/*

while condition loop
    statements
end loop;
*/

declare
    iter integer :=0;
begin
    while iter<5 loop
        dbms_output.put_line('Iter: '||iter);
        iter:=iter+1;
    end loop;
end;

-- Using while loop display the name of department with ID 60,70,80,90.
declare
    dept integer:=60;
    name varchar(20);
begin
    while dept<100 loop
        select department_name into name from department where department_id=dept;
        dept:=dept+10;
        dbms_output.put_line(name);
    end loop;
end;

-- FOR LOOP

declare
    counter integer;
begin
    for counter IN 1..5 loop
        dbms_output.put_line(counter);
    end loop;
end;

declare
    counter integer;
begin
    for counter IN REVERSE 1..5 loop
        dbms_output.put_line(counter);
    end loop;
end;

-- CURSOR FOR LOOP

declare
    v_rec employee%ROWTYPE;
begin
    for v_rec in (select * from employee where department_id=30) loop
        dbms_output.put_line('Name: '||v_rec.first_name||' Salary: '||v_rec.salary);
    end loop;
end;

-- Oracle 21c+ increment control
declare
    starting integer:=1;
    ending integer:=20;
    counter integer:=0;
begin
    for counter in starting..ending by 2 loop
        dbms_output.put_line(counter);
    end loop;
end;

declare
    starting integer:=1;
    ending integer:=20;
begin
    for counter in starting..ending by 2 loop -- counter dynamically created
        dbms_output.put_line(counter);
    end loop;
    -- dbms_output.put_line(counter); -- local to loop, not accessible here
end;


-- Create a '*' pyramid of N lines using loop

declare
    lines integer:=0;
    counter integer:=1;
begin
    lines:=&EnterLines;
    while counter<=lines loop
        for n in 1..(lines-counter) loop
        dbms_output.put(' ');
        end loop;
        for n in 1..counter loop
        dbms_output.put('* ');
        end loop;
    dbms_output.put_line(' ');
    counter:=counter+1;
    end loop;
end;

-- Using loop, check from account balance from accounts table and increment balance by 2000 if balance is below 
    -- 2500 rupees. Else do nothing.

declare
    v_rec accounts%ROWTYPE;
    counter integer :=0;
begin
    for v_rec in (select * from accounts) loop
        if v_rec.acc_balance<2500 then
            update accounts set acc_balance=acc_balance+2000 where acc_nu=v_rec.acc_nu;
            counter:=counter+1;
        end if;
    end loop;
    dbms_output.put_line(counter||' accounts updated.');
end;

-- Exception Handling

declare
    v_rec employee%ROWTYPE;
    v_dept integer default 0;
begin
    v_dept:=&EnterDept;
    select * into v_rec from employee where department_id=v_dept;
    dbms_output.put_line('Value: '||(230/0));
exception
    when no_data_found then dbms_output.put_line('No Data Found for department: '||v_dept);
    when too_many_rows then dbms_output.put_line('More than 1 row for department: '||v_dept);
    when others then dbms_output.put_line('Other Error');
end;

-- Formulate a code to demostrate DUP_VAL_ON_INDEX exception for insert operation
insert into sample_data values(101, 'sample_101');

begin
    insert into sample_data values(101, 'sample_new');
exception
    when DUP_VAL_ON_INDEX then dbms_output.put_line('Duplicate Entry to Sample');
    when others then dbms_output.put_line('Other Error!');
end;

-- unnamed exception
declare
    dept_integrity EXCEPTION;
    PRAGMA EXCEPTION_INIT(dept_integrity, -2292);
begin
    delete from products where pid=401;
    commit;
exception
    when dept_integrity then DBMS_OUTPUT.PUT_LINE('Can not remove product, sales exist.');
    when others then DBMS_OUTPUT.PUT_LINE('Other Error!');
end;

-- Demonstrate -02270 error "NO MATCHING UNIQUE OR PRIMARY KEY" in case when you want to enter record for FK
    -- that does not exist.

declare
    sales_check EXCEPTION;
    PRAGMA EXCEPTION_INIT(sales_check, -2291);
begin
    insert into sales_data values(903, 409, to_date('21-Feb-26'));
    commit;
exception
    when sales_check then DBMS_OUTPUT.PUT_LINE('Can not record sales for undefined product.');
    when others then DBMS_OUTPUT.PUT_LINE('Other Error!');
end;