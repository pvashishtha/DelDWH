-- Write PLSQL procedure code to accept table name and column name from user as parameter and find if table has 
    -- duplicate records, then print on screen the count of duplicate records, else print message if it does not 
    -- have any duplicates.

create or replace procedure find_duplicate_records_count(tablename varchar, columnname varchar) is
    v_sql varchar2(500);
begin
    v_sql:=
    'select '||columnname||', count('||columnname||') from '||tablename||' group by '||columnname||' having count('||columnname||')>1';
    EXECUTE IMMEDIATE v_sql;
    if (SQL%ROWCOUNT)>0 then
        dbms_output.put_line('duplicate recors found in table '||tablename);
    else
        dbms_output.put_line('No duplicate records found.');
    end if;
end;

exec find_duplicate_records_count('mydata', 'data_is');

-- PACKAGES

-- package specification
create or replace package simple_math is
    pi number :=22/7;
    procedure area_circle(radius IN number);
    procedure volume_cylinder(radius IN number, height IN number);
end simple_math;

-- package body
create or replace package body simple_math is
    function round_simple(val number) return number is
    begin
        return trunc(val, 2);    
    end;

    procedure area_circle(radius IN number) is
        v_area number;
    begin
        v_area:=round_simple(pi)*(radius**2);
        dbms_output.put_line('Area Circle: '||v_area);
    end;

    procedure volume_cylinder(radius IN number, height IN number) is
        v_volume number;
    begin
        v_volume:=round_simple(pi)*(radius**2)*height;
        dbms_output.put_line('Volume Cylinder: '||v_volume);
    end;
end simple_math;

-- package items invocation
begin
    simple_math.area_circle(3);
    simple_math.volume_cylinder(3, 5);
    dbms_output.put_line(simple_math.pi);
    -- simple_math.round_simple(3.145786); -- private to body of package
end;


-- Create a package "table_operations" that has procedures 1. get_employee_by_id 2. get_all_employees_for_dept
    -- 3. update_employee_salary

create or replace package table_operations is
    procedure get_employee_by_id(empid int);
    procedure get_all_employees_for_dept(dept int);
    procedure update_employee_salary(sal number, empid int);
end table_operations;

create or replace package body table_operations is
    procedure get_employee_by_id(empid int) is
        v_rec employee%rowtype;
    begin
        select * into v_rec from employee where employee_id=empid;
        DBMS_OUTPUT.PUT(v_rec.employee_id||' ');
        DBMS_OUTPUT.PUT(v_rec.first_name||' ');
        DBMS_OUTPUT.PUT(v_rec.salary||' ');
        DBMS_OUTPUT.PUT_LINE(v_rec.job_id||' ');
    end;

    procedure get_all_employees_for_dept(dept int) is
        CURSOR cur is select * from employee where department_id=dept;
        v_rec employee%rowtype;
    begin
        open cur;
        loop
            fetch cur into v_rec;
            exit when cur%notfound;
            DBMS_OUTPUT.PUT(v_rec.employee_id||' ');
            DBMS_OUTPUT.PUT(v_rec.first_name||' ');
            DBMS_OUTPUT.PUT(v_rec.salary||' ');
            DBMS_OUTPUT.PUT_LINE(v_rec.job_id||' ');
        end loop;
        
    end;

    procedure update_employee_salary(sal number, empid int) is
    begin
        update employee set salary=sal where employee_id=empid;
    end;
end table_operations;

begin
    TABLE_OPERATIONS.UPDATE_EMPLOYEE_SALARY(100, 31000);
end;

-- Bodiless Packages -> without body, but have specification only

create or replace package const_vars is
    kilometer_to_mile number := 0.62;
    mile_to_kilometer number := 1.61;
end const_vars;

BEGIN
    dbms_output.put_line('20 kilometer is same as '||20*const_vars.kilometer_to_mile||' miles.');
    dbms_output.put_line('and, 20 miles is same as '||20*const_vars.mile_to_kilometer||' kilometers.');
END;

-- Overloading 
    -- proceudre or func having same name and different parameter list
    -- parameter can be different in count, data type, order

create or replace package get_employees is
    procedure get_all_employees(dept number);
    procedure get_all_employees(jobid varchar);
end get_employees;

create or replace package body get_employees is
    procedure get_all_employees(dept number) is
        CURSOR cur is select * from employee where department_id=dept;
        v_rec employee%rowtype;
    begin
        open cur;
        loop
            fetch cur into v_rec;
            exit when cur%notfound;
            dbms_output.put(v_rec.employee_id||' ');
            dbms_output.put_line(v_rec.first_name);  
        end loop;  
        close cur;    
    end;

    procedure get_all_employees(jobid varchar) is
       CURSOR cur is select * from employee where job_id=jobid;
        v_rec employee%rowtype;
    begin
        open cur;
        loop
            fetch cur into v_rec;
            exit when cur%notfound;
            dbms_output.put(v_rec.employee_id||' ');
            dbms_output.put_line(v_rec.first_name);  
        end loop; 
        close cur;
    end;
end get_employees;

begin
    get_employees.GET_ALL_EMPLOYEES('SA_MAN');
end;

-- TRIGGERS
create or replace trigger update_employee_salary_trigger 
before update on employee for each row
begin
    if :NEW.salary<:OLD.salary then
        :NEW.salary:=:OLD.salary;
    end if;
end;

update employee set salary=14000 where employee_id=100;
commit;

select first_name, salary from employee where employee_id=100;

-- 

select logseq.nextval from dual;

create or replace trigger emp_update
after update on employee for each row
begin
    insert into emp_log 
    values(logseq.nextval, 'Employee table updated at ID '||:OLD.employee_id||' by '||user, sysdate);
end;

-- create delete and insert log triggers
create or replace trigger emp_delete
after delete on employee for each row
begin
    insert into emp_log 
    values(logseq.nextval, 'Employee table deleted at ID '||:OLD.employee_id||' by '||user, sysdate);
end;

create or replace trigger emp_insert
after insert on employee for each row
begin
    insert into emp_log 
    values(logseq.nextval, 'Employee table inserted at ID '||:NEW.employee_id||' by '||user, sysdate);
end;



update employee set salary=19000 where employee_id=201;
insert into employee(employee_id, first_name, last_name, salary, department_id, email, hire_date, manager_id, job_id)
    values(209, 'Prateek', 'Vashishtha', 39000, 90, 'prateek@email.com', '20-Feb-26', 100, 'AD_VP');
delete from employee where employee_id=209;
commit;

select * from emp_log order by logid;

-- trigger with conditional predicates
create or replace trigger secure_emp
before insert or update or delete on employee
begin
    if to_number(to_char(sysdate, 'HH'))<10 or to_number(to_char(sysdate, 'HH'))>18 then
        if deleting then
            RAISE_APPLICATION_ERROR(-20100, 'You may delete employee record only during office hours');
        elsif updating('salary') then
            RAISE_APPLICATION_ERROR(-20200, 'You may update employee record only during office hours');
        end if;
    end if;
end;

-- COLLECTIONS

-- Associative Arrays
    -- key-value pairs
    -- dynamic in size
    
DECLARE
    TYPE name_type IS TABLE OF VARCHAR2(50) INDEX BY PLS_INTEGER; 
    names name_type;
    idx integer;
BEGIN
    names(1) := 'Prateek';
    names(2) :='Simant';
    names(3) :='Neha';

    dbms_output.put_line('Name at position 2 is: '||names(2));
    dbms_output.put_line('FIRST INDEX IN ARRAY: '||names.FIRST);

    idx:=names.FIRST;

    while idx is not null loop
            dbms_output.put_line(names(idx));
            idx:=names.NEXT(idx);
    end loop;    
END;

-- Create an implementation for storing marks of students indexed by names in an associative array and display 
-- those marks using array
DECLARE
    TYPE marks_type IS TABLE OF integer INDEX BY VARCHAR2(50);
    marks marks_type;
    idx varchar2(50);
BEGIN
    marks('prateek') := 90;
    marks('amit'):=87;
    marks('aditi'):=99;
    marks('sanjay'):=86;
    marks('anand'):=76;

    idx:=marks.FIRST;
    while idx is not null loop
        dbms_output.put_line('Marks for '||idx||' is '||marks(idx));
        idx:=marks.NEXT(idx);
    end loop;
END;

-- NESTED TABLE
create type product_item_type as OBJECT(prodid int, price number);

create type nested_product_type as table of product_item_type;

create table sales_items(
    supplier number,
    requester number,
    order_date date,
    items nested_product_type)
    NESTED TABLE items STORE AS items_table;

insert into sales_items values(
    101, 201, '20-Feb-26',
    nested_product_type(
        product_item_type(401, 230),
        product_item_type(402, 145),
        product_item_type(403, 455)
        )
);

insert into sales_items values(
    105, 208, sysdate,
    nested_product_type(
        product_item_type(407, 130)
        )
);

select * from sales_items;

select items from SALES_ITEMS;

select t1.supplier, t2.* from sales_items t1, table(t1.items) t2;


-- VARRAY

create type array_type as object(course_id int, course_name varchar2(20), course_fee number);

create type course_details as varray(50) of array_type;

create table student(
    stdid int,
    stdname varchar2(100),
    course course_details);


insert into student values(901, 'prateek', course_details(array_type(10, 'SQL', 2300)));

insert into student values(902, 'simant', course_details(array_type(20, 'Java', 1600)));

insert into student values(903, 'neha', course_details(array_type(30, 'Python', 3000), array_type(20, 'Java', 1600)));

select * from student;

select t1.stdid, t2.* from student t1, table(t1.course) t2;


-- Simple VARRAY example

declare
    TYPE namesarray IS VARRAY(5) OF VARCHAR2(20);
    TYPE gradesarray IS VARRAY(5) OF INTEGER;

    names namesarray := namesarray('Prateek','Alan','John','Nancy','Rita');
    grades gradesarray := gradesarray(98, 94, 87, 76, 79);

    asize integer;
begin
    asize:=names.COUNT;
    dbms_output.put_line('Total Elements: '||asize);

    for i in 1..asize loop
        dbms_output.put_line('Name: '||names(i)||CHR(10)||'Grade: '||grades(i));
    end loop;
end;

declare
    TYPE namesarray IS VARRAY(10) OF VARCHAR2(20);
    TYPE gradesarray IS VARRAY(10) OF INTEGER;

    names namesarray := namesarray('Prateek','Alan','John','Nancy','Rita');
    grades gradesarray := gradesarray(98, 94, 87, 76, 79);

    asize integer;
begin
    asize:=names.COUNT;
    dbms_output.put_line('Total Elements: '||asize);

    for i in 1..asize loop
        dbms_output.put_line('Name: '||names(i)||CHR(10)||'Grade: '||grades(i));
    end loop;

    names.EXTEND;
    grades.EXTEND;

    dbms_output.put_line('----------------');

    asize:=names.COUNT;
    dbms_output.put_line('Total Elements: '||asize);

    for i in 1..asize loop
        dbms_output.put_line('Name: '||names(i)||CHR(10)||'Grade: '||grades(i));
    end loop;

    names.EXTEND;
    grades.EXTEND;

    dbms_output.put_line('----------------');

    names(6):='aditi';
    grades(6):=99;

    names(7):='saksham';
    grades(7):=89;

    asize:=names.COUNT;
    dbms_output.put_line('Total Elements: '||asize);

    for i in 1..asize loop
        dbms_output.put_line('Name: '||names(i)||CHR(10)||'Grade: '||grades(i));
    end loop;

end;

-- BULK COLLECT -> select bulk data
declare
    type namesarray is varray(200) of employee.first_name%TYPE;
    names namesarray;
begin
    select first_name BULK COLLECT INTO names from employee where department_id=80;

    for i in 1..names.COUNT loop
        dbms_output.put_line('Name: '||names(i));
    end loop;
end;

-- FORALL -> bulk DML operations

declare
    type empid_array is varray(200) of employee.employee_id%type;
    empid empid_array;
begin
    select employee_id BULK COLLECT INTO empid from employee;

    FORALL i in empid.FIRST..empid.LAST
        update employee set commission_pct=round(salary/100000, 2) where employee_id=empid(i);   
        commit;
end;

-- Write a code to bulk collect all distinct department names from cursor to varray

declare
    CURSOR cur is select department_name from department;
    type dept_array is varray(50) of department.department_name%type;
    dept dept_array;
begin
    open cur;
    fetch cur bulk collect into dept limit 5;
    for i in dept.first..dept.last loop
        dbms_output.put_line(dept(i));
    end loop;
    close cur;
end;

-- SQL%ROWCOUNT
    -- SQL%BULK_ROWCOUNT(n) -> can be used in FORALL DML operations, give coutn fo rows affected in nth operation

declare
    type deptarray is varray(50) of department.department_id%type;
    dept deptarray;
    cursor cur is select department_id from department order by department_id;
begin
    open cur;
    fetch cur bulk collect into dept;
    forall i in dept.first..dept.last
        update employee set salary=salary*1.05 where department_id=dept(i);
        commit;
    dbms_output.put_line('Rows Affected for 3rd operation: '||SQL%BULK_ROWCOUNT(3));
    close cur;
exception 
    when no_data_found then dbms_output.put_line('NO DEPARTMENT FOUND');
    when others then dbms_output.put_line('Some Error Occured!');
end;

-- Write a code to copy employee data to a new table emp2 using bulk insert operation. Use cursor to read
    -- all data from employee and bulk insert into new table 

create table emp2(employee_id int, first_name varchar2(20), last_name varchar2(20), salary number, 
    department_id int, job_id varchar2(20));

declare
    type emparray is varray(200) of emp2%rowtype;
    empdata emparray;
    cursor cur is select employee_id, first_name, last_name, salary, department_id, job_id from employee;
begin
    open cur;
    fetch cur bulk collect into empdata;
    -- save exceptions for bulk operation
    forall i in empdata.first..empdata.last save exceptions
        insert into emp2 values(
            empdata(i).employee_id,
            empdata(i).first_name,
            empdata(i).last_name,
            empdata(i).salary,
            empdata(i).department_id,
            empdata(i).job_id
        );
    close cur;
exception when others then dbms_output.put_line('Some Error!');    
end;

select * from emp2;

--